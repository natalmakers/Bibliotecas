/*---------------------------------------------
 S H I F T O U T M E G A
 Ampliar o n�mero de sa�das do Arduino com
 Registrador de Deslocamento 74HC595
 Fellipe Couto - 17/09/2012
 --------------------------------------------*/
#ifndef ShiftOutMega_h  
#define ShiftOutMega_h  
#include "Arduino.h"
class ShiftOutMega{  
	public:
		ShiftOutMega(int latchPin, int dataPin, int clockPin, int qtdRegister);
		void xdigitalWrite(int pin, boolean state);
	private:
		int _latchPin;
		int _dataPin;
		int _clockPin;
		int _qtdRegister;
		void shiftOut(byte dataOut);
		String decToBin(int myNum);
		int binToDec(String b);
		int potencia(int b, int e);
};
#endif
