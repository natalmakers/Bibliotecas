Basic library that reads a NTC thermistor from an analog pin. Calculations relie on
Steinhart–Hart equation:

https://en.wikipedia.org/wiki/Thermistor#Steinhart.E2.80.93Hart_equation

See the example for more information.

Example of use with panStamp:
https://github.com/panStamp/panstamp/wiki/Temperature-measurement-with-cheap-NTC's
