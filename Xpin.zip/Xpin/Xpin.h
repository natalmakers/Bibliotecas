/*
BIBLIOTECA Xpin
Esta biblioteca � uma adapta��o da seguinte biblioteca:
*/

/*--------------------------------------------- 
 S H I F T O U T M E G A
 Ampliar o n�mero de sa�das do Arduino com
 Registrador de Deslocamento 74HC595
 Fellipe Couto - 17/09/2012
 --------------------------------------------*/
#ifndef XPIN  
#define XPIN  
#include "Arduino.h"
class Xpin{  
	public:
				
		Xpin();
		void xdigitalWrite(int pin, boolean state);
	private:
		int _latchPin;
		int _dataPin;
		int _clockPin;
		int _qtdRegister;
		void xOut(byte dataOut);
		String decToBin(int myNum);
		int binToDec(String b);
		
};


#endif



